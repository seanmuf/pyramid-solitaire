import static org.junit.Assert.assertEquals;

import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.Card.Suits;
import cs3500.pyramidsolitaire.model.hw02.Card.Values;
import org.junit.Test;

/**
 * Tests for {@Link Card}s.
 */
public class CardTest {

  @Test
  public void testSumTwoCards() {
    Card card1 = new Card(Values.Seven, Suits.Hearts);
    Card card2 = new Card(Values.Ten, Suits.Hearts);

    assertEquals(17, card1.sumTwoCards(card2));
    assertEquals(7, card1.sumTwoCards(null));
  }

  @Test
  public void testCopyCard() {
    Card card1 = new Card(Values.Seven, Suits.Hearts);
    Card card2 = new Card(Values.Seven, Suits.Hearts);
    Card card3 = new Card(Values.Ten, Suits.Hearts);
    Card card4 = new Card(Values.Ten, Suits.Hearts);

    assertEquals(card2, card1.copyCard());
    assertEquals(card4, card3.copyCard());
  }

  @Test
  public void testfindSum() {
    Card card1 = new Card(Values.A, Suits.Hearts);
    Card card2 = new Card(Values.Jack, Suits.Hearts);
    Card card3 = new Card(Values.Queen, Suits.Hearts);

    assertEquals(1, card1.findSum());
    assertEquals(11, card2.findSum());
    assertEquals(12, card3.findSum());
  }

  @Test
  public void testToString() {
    Card card1 = new Card(Values.Jack, Suits.Hearts);
    Card card2 = new Card(Values.Seven, Suits.Spades);

    assertEquals("J♥", card1.toString());
    assertEquals("7♠", card2.toString());
  }

  @Test
  public void testGetNumVal() {
    Card card1 = new Card(Values.Jack, Suits.Hearts);
    Card card2 = new Card(Values.Seven, Suits.Spades);
    Card card3 = new Card(Values.Queen, Suits.Hearts);

    assertEquals(11, card1.findSum());
    assertEquals(7, card2.findSum());
    assertEquals(12, card3.findSum());

  }


}

