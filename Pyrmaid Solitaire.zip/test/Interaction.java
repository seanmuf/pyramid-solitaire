/**
 * Represents an interaction between a controller and a user.
 */
public interface Interaction {
  void apply(StringBuilder in, StringBuilder out);
}
