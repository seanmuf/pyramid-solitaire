import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire.gameState;
import cs3500.pyramidsolitaire.model.hw02.Card.Suits;
import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.Card.Values;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import java.util.ArrayList;

import static junit.framework.TestCase.assertEquals;

import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@Link BasicPyramidSolitaire}s.
 */
public class BasicPyramidSolitaireTest {

  protected List<ArrayList<Card>> pyramid;
  protected List<Card> stock;
  protected List<Card> draw;
  protected gameState status;
  protected PyramidSolitaireModel test1;

  @Before
  public void init() {

    ArrayList<ArrayList<Card>> result = new ArrayList<>();
    Card card1 = new Card(Values.Seven, Suits.Hearts);
    Card card2 = new Card(Values.Six, Suits.Spades);
    Card card3 = new Card(Values.Seven, Suits.Hearts);
    ArrayList<Card> row1 = new ArrayList<>();
    row1.add(card1);

    ArrayList<Card> row2 = new ArrayList<>();
    row2.add(card2);
    row2.add(card3);

    ArrayList<Card> row3 = new ArrayList<>();
    row3.add(card1);
    row3.add(card1);
    row3.add(card2);

    result.add(row1);
    result.add(row2);
    result.add(row3);

    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire(result,
        new ArrayList<>(), row2, gameState.NotPlaying);

    pyramid = result;
    draw = row2;
    status = gameState.Playing;
    stock = test2.getDeck();

    test1 = new BasicPyramidSolitaire(pyramid, stock, draw, status);
    test2 = new RelaxedPyramidSolitaire(pyramid, stock, draw, status);
  }

  @Test
  public void testGetCardAt() {
    Card card1 = new Card(Values.Seven, Suits.Hearts);
    Card card2 = new Card(Values.Six, Suits.Spades);
    Card card3 = new Card(Values.Seven, Suits.Hearts);

    assertEquals(card3, test1.getCardAt(1, 1));
    assertEquals(card2, test1.getCardAt(2, 2));
    assertEquals(card1, test1.getCardAt(0, 0));
  }

  @Test
  public void testGetScore() {
    assertEquals(40, test1.getScore());
  }

  @Test
  public void testGetRowWidth() {
    assertEquals(3, test1.getRowWidth(2));
    assertEquals(2, test1.getRowWidth(1));
    assertEquals(1, test1.getRowWidth(0));
  }

  @Test
  public void testGetNumDraw() {
    assertEquals(2, test1.getNumDraw());
  }


  @Test
  public void testIsGameOver() {
    assertEquals(false, test1.isGameOver());

  }

}
