import static junit.framework.TestCase.assertEquals;

import cs3500.pyramidsolitaire.controller.PyramidSolitaireController;
import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;
import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire.gameState;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.Card.Suits;
import cs3500.pyramidsolitaire.model.hw02.Card.Values;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.TriPeaksPyramidSolitaire;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import org.junit.Test;

/**
 * Tests for {@Link PyramidSolitaireTextualController}s.
 */
public class PyramidSolitaireTextualControllerTest {

  /**
   * Initializes variables for tests.
   */
  public void init() {
    ArrayList<ArrayList<Card>> result = new ArrayList<>();
    Card card1 = new Card(Values.King, Suits.Hearts);
    Card card2 = new Card(Values.Eight, Suits.Hearts);
    Card card3 = new Card(Values.Jack, Suits.Hearts);
    ArrayList<Card> row1 = new ArrayList<>();
    row1.add(card1);

    ArrayList<Card> row2 = new ArrayList<>();
    row1.add(card2);
    row1.add(card3);

    ArrayList<Card> row3 = new ArrayList<>();
    row1.add(card1);
    row1.add(card2);
    row1.add(card3);

    result.add(row1);
    result.add(row2);
    result.add(row3);

    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);
    BasicPyramidSolitaire test3 = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);
  }

  void testRunBasic(PyramidSolitaireModel model, Interaction... interactions) throws IOException {
    BasicPyramidSolitaire game = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);
    BasicPyramidSolitaire game1 = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader in = new StringReader(fakeUserInput.toString());
    StringBuilder out = new StringBuilder();

    PyramidSolitaireTextualController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(game, game1.getDeck(), false, 5, 3);

    assertEquals(expectedOutput.toString(), out.toString());
  }

  void testRunRelaxed(PyramidSolitaireModel model, Interaction... interactions) throws IOException {
    RelaxedPyramidSolitaire game = new RelaxedPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);
    RelaxedPyramidSolitaire game1 = new RelaxedPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader in = new StringReader(fakeUserInput.toString());
    StringBuilder out = new StringBuilder();

    PyramidSolitaireTextualController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(game, game1.getDeck(), false, 5, 3);

    assertEquals(expectedOutput.toString(), out.toString());
  }

  void testRunTripeaks(PyramidSolitaireModel model, Interaction... interactions)
      throws IOException {
    TriPeaksPyramidSolitaire game = new TriPeaksPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);
    TriPeaksPyramidSolitaire game1 = new TriPeaksPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader in = new StringReader(fakeUserInput.toString());
    StringBuilder out = new StringBuilder();

    PyramidSolitaireTextualController controller = new PyramidSolitaireTextualController(in, out);
    controller.playGame(game, game1.getDeck(), false, 5, 3);

    assertEquals(expectedOutput.toString(), out.toString());
  }

  static Interaction prints(String... lines) {
    return (input, output) -> {
      for (String line : lines) {
        output.append(line).append('\n');
      }
    };
  }

  static Interaction inputs(String in) {
    return (input, output) -> {
      input.append(in);
    };
  }

  static Interaction outputs(String... lines) {
    return (input, output) -> {
      for (String line : lines) {
        output.append(line).append('\n');
      }
    };
  }

  @Test
  public void testQuitGameMoveBasic() throws IOException {
    testRunBasic(new BasicPyramidSolitaire(),
        inputs("q rm1 3 2"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥  \n"
            + "      A♦  A♣  \n"
            + "    A♠  2♥  2♦  \n"
            + "  2♣  2♠  3♥  3♦  \n"
            + "3♣  3♠  4♥  4♦  4♣  \n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36"));

  }

  @Test
  public void testQuitGameRowBasic() throws IOException {
    testRunBasic(new BasicPyramidSolitaire(),
        inputs("rm1 q 2"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥  \n"
            + "      A♦  A♣  \n"
            + "    A♠  2♥  2♦  \n"
            + "  2♣  2♠  3♥  3♦  \n"
            + "3♣  3♠  4♥  4♦  4♣  \n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36"));

  }

  @Test
  public void testQuitGameCardBasic() throws IOException {
    testRunBasic(new BasicPyramidSolitaire(),
        inputs("rm1 3 q"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥\n"
            + "      A♦  A♣\n"
            + "    A♠  2♥  2♦\n"
            + "  2♣  2♠  3♥  3♦\n"
            + "3♣  3♠  4♥  4♦  4♣\n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36".stripTrailing()));

  }

  @Test
  public void testQuitGameMove() throws IOException {
    testRunRelaxed(new RelaxedPyramidSolitaire(),
        inputs("q rm1 3 2"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥  \n"
            + "      A♦  A♣  \n"
            + "    A♠  2♥  2♦  \n"
            + "  2♣  2♠  3♥  3♦  \n"
            + "3♣  3♠  4♥  4♦  4♣  \n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36"));

  }

  @Test
  public void testQuitGameRowRelaxed() throws IOException {
    testRunRelaxed(new RelaxedPyramidSolitaire(),
        inputs("rm1 q 2"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥  \n"
            + "      A♦  A♣  \n"
            + "    A♠  2♥  2♦  \n"
            + "  2♣  2♠  3♥  3♦  \n"
            + "3♣  3♠  4♥  4♦  4♣  \n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36"));

  }

  @Test
  public void testQuitGameCardRelaxed() throws IOException {
    testRunRelaxed(new RelaxedPyramidSolitaire(),
        inputs("rm1 3 q"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥\n"
            + "      A♦  A♣\n"
            + "    A♠  2♥  2♦\n"
            + "  2♣  2♠  3♥  3♦\n"
            + "3♣  3♠  4♥  4♦  4♣\n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36".stripTrailing()));

  }

  @Test
  public void testQuitGameMoveTripeaks() throws IOException {
    testRunTripeaks(new TriPeaksPyramidSolitaire(),
        inputs("q rm1 3 2"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥  \n"
            + "      A♦  A♣  \n"
            + "    A♠  2♥  2♦  \n"
            + "  2♣  2♠  3♥  3♦  \n"
            + "3♣  3♠  4♥  4♦  4♣  \n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36"));

  }

  @Test
  public void testQuitGameRowTripeaks() throws IOException {
    testRunTripeaks(new TriPeaksPyramidSolitaire(),
        inputs("rm1 q 2"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥  \n"
            + "      A♦  A♣  \n"
            + "    A♠  2♥  2♦  \n"
            + "  2♣  2♠  3♥  3♦  \n"
            + "3♣  3♠  4♥  4♦  4♣  \n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36"));

  }

  @Test
  public void testQuitGameCardTriPeaks() throws IOException {
    testRunTripeaks(new TriPeaksPyramidSolitaire(),
        inputs("rm1 3 q"),
        prints("Game quit!\n"
            + "State of game when quit:\n"
            + "        A♥\n"
            + "      A♦  A♣\n"
            + "    A♠  2♥  2♦\n"
            + "  2♣  2♠  3♥  3♦\n"
            + "3♣  3♠  4♥  4♦  4♣\n"
            + "Draw: 4♠, 5♥, 5♦\n"
            + "Score: 36".stripTrailing()));

  }


  @Test
  public void testBogusInputBasic() throws IOException {
    testRunBasic(new BasicPyramidSolitaire(),
        inputs("rmwd 0 0 0 0"),
        prints("Invalid move. Play again. " + "You can't make that move." + "\n"));
  }

  @Test
  public void testBogusInputRelaxed() throws IOException {
    testRunRelaxed(new RelaxedPyramidSolitaire(),
        inputs("rmwd 0 a"),
        prints("Invalid move. Play again. " + "You can't make that move." + "\n"));
  }

  @Test
  public void testBogusInputTripeak() throws IOException {
    testRunTripeaks(new TriPeaksPyramidSolitaire(),
        inputs("rmwd 0 0 0 x"),
        prints("Invalid move. Play again. " + "You can't make that move." + "\n"));
  }


  @Test
  public void testControllerBadInputsNULLRD() {
    try {
      PyramidSolitaireController cont = new PyramidSolitaireTextualController(null,
          new StringBuilder());
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), "Invalid Argument");
    }
  }

  @Test
  public void testControllerBadInputsNullAP() {
    try {
      PyramidSolitaireController cont = new PyramidSolitaireTextualController(
          new StringReader(""), null);
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), "Invalid Argument");
    }
  }

  @Test
  public void testPlayGameBadInputNullModelBasic() {
    this.init();
    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    try {
      cont.playGame(null, test2.getDeck(), false, 4, 3);
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), "Model can't be null.");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidRowBasic() {
    this.init();
    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    BasicPyramidSolitaire model = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, test2.getDeck(), false, -5, 3);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidDrawBasic() {
    this.init();
    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    BasicPyramidSolitaire model = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, test2.getDeck(), false, 3, 20);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidDeckBasic() {
    this.init();
    BasicPyramidSolitaire test2 = new BasicPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    BasicPyramidSolitaire model = new BasicPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, new ArrayList<>(), false, 7, 5);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputNullModelRelaxed() {
    this.init();
    RelaxedPyramidSolitaire test2 = new RelaxedPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    try {
      cont.playGame(null, test2.getDeck(), false, 4, 3);
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), "Model can't be null.");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidRowRelaxed() {
    this.init();
    RelaxedPyramidSolitaire test2 = new RelaxedPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    RelaxedPyramidSolitaire model = new RelaxedPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, test2.getDeck(), false, -5, 3);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidDrawRelaxed() {
    this.init();
    RelaxedPyramidSolitaire test2 = new RelaxedPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    RelaxedPyramidSolitaire model = new RelaxedPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, test2.getDeck(), false, 7, 30);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidDeckRelaxed() {
    this.init();
    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    RelaxedPyramidSolitaire model = new RelaxedPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, new ArrayList<>(), false, 7, 5);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputNullModelTripeaks() {
    this.init();
    TriPeaksPyramidSolitaire test2 = new TriPeaksPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    try {
      cont.playGame(null, test2.getDeck(), false, 4, 3);
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), "Model can't be null.");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidRowTripeaks() {
    this.init();
    TriPeaksPyramidSolitaire test2 = new TriPeaksPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    TriPeaksPyramidSolitaire model = new TriPeaksPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, test2.getDeck(), false, -5, 3);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidDrawTripeaks() {
    this.init();
    TriPeaksPyramidSolitaire test2 = new TriPeaksPyramidSolitaire(new ArrayList<>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    TriPeaksPyramidSolitaire model = new TriPeaksPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, test2.getDeck(), false, 3, 100);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }

  @Test
  public void testPlayGameBadInputInvalidDeckTripeaks() {
    this.init();
    PyramidSolitaireController cont =
        new PyramidSolitaireTextualController(new StringReader(""), new StringBuilder());

    TriPeaksPyramidSolitaire model = new TriPeaksPyramidSolitaire(new ArrayList<ArrayList<Card>>(),
        new ArrayList<>(), new ArrayList<>(), gameState.NotPlaying);

    try {
      cont.playGame(model, new ArrayList<>(), false, 7, 5);
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Invalid input");
    }
  }


}


