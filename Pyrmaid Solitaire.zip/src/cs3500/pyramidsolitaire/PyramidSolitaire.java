package cs3500.pyramidsolitaire;

/**
 * Represents pyramid solitaire.
 */
public final class PyramidSolitaire {

  /**
   * Play a game of pyramid solitaire.
   * @param args game type and specifications.
   */
  public static void main(String[] args) {
    StringBuilder rd = new StringBuilder();
  }
}