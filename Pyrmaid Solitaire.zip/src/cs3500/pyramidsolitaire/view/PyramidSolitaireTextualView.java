package cs3500.pyramidsolitaire.view;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import java.io.IOException;

/**
 * Represents a textual view of the pyrmaid solitaire game.
 */
public class PyramidSolitaireTextualView implements PyramidSolitaireView {

  /**
   * Constructs a pyramid solitaire model.
   *
   * @param model the game to de drawn.
   */
  private final PyramidSolitaireModel<?> model;
  private Appendable ap;

  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model) {
    this.model = model;
  }

  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model, Appendable ap) {
    this.model = model;
    this.ap = ap;
  }

  @Override
  public String toString() {
    int rows = model.getNumRows();
    String result = "";
    if (model.getNumRows() == -1) {
      return "";
    }
    if (model.getScore() == 0) {
      return "You win!";
    }
    if (model.isGameOver()) {
      return "Game over. Score:" + " " + model.getScore();
    }
    for (int i = 0; i < rows; i++) {
      if (i != 0) {
        result = result + "\n";
      }
      for (int j = 0; j < (rows - i - 1); j++) {
        result = result + "  ";
      }
      for (int k = 0; k <= i; k++) {
        if ((model.getCardAt(i, k) == null)) {
          result = result + " ";
        } else {
          if ((model.getCardAt(i, k).toString().length() == 2)) {
            result = result + (model.getCardAt(i, k)).toString() + "  ";
          } else {
            result = result + (model.getCardAt(i, k)).toString() + " ";
          }
        }
      }
      result = result.stripTrailing();
    }
    return result.stripTrailing() + "\n" + "Draw:" + drawDrawCards().stripTrailing();
  }

  private String drawDrawCards() {
    String result = "";
    for (int i = 0; i < (model.getDrawCards().size()); i++) {
      if (model.getDrawCards().get(i) == null) {
        result += "";
      } else {
        if (i == ((model.getDrawCards().size()) - 1)) {
          result = result + " " + (model.getDrawCards().get(i).toString());
        } else {
          result = result + " " + (model.getDrawCards().get(i).toString()) + ",";
        }
      }
    }
    return result.stripTrailing();
  }

  @Override
  public void render() throws IOException {
    ap.append(this.toString());
  }
}
