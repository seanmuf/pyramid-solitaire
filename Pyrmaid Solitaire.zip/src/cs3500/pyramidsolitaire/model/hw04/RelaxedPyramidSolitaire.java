package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a game of Relaxed Pyramid Solitaire. Pyramid is the current game of cards. Stock is
 * the deck of cards that can be drawn from. Status is the current state of the game: either Playing
 * or NotPlaying.
 */
public class RelaxedPyramidSolitaire extends BasicPyramidSolitaire {

  /**
   * Constructs a RelaxedPyramidSolitaire.
   *
   * @param pyramid the solitaire pyramid.
   * @param stock   the cards in the stock pile.
   * @param draw    the cards in the draw pile.
   * @param status  the state of the game.
   */
  public RelaxedPyramidSolitaire(List<ArrayList<Card>> pyramid, List<Card> stock,
      List<Card> draw, gameState status) {
    this.pyramid = pyramid;
    this.stock = stock;
    this.draw = draw;
    this.status = status;

  }

  /**
   * Initializes a game of pyramid solitaire.
   */
  public RelaxedPyramidSolitaire() {
    status = gameState.NotPlaying;
    pyramid = new ArrayList<ArrayList<Card>>();
  }

  @Override
  protected boolean isExposed(int row, int card) {
    if (row == getNumRows() - 1) {
      return true;
    } else {
      return (this.getCardAt(row + 1, card) == null
          || this.getCardAt(row + 1, card + 1) == null);
    }
  }


}
