package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire.gameState;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import java.util.ArrayList;

/**
 * Represents a pyramid solitaire creator. It creates an instance of one of the three possible
 * pyramid solitaire games (Basic, Relaxed, Tripeak).
 */
public class PyramidSolitaireCreator {

  /**
   * gameState represents the two states of a pyramid solitaire game:Playing and NotPlaying.
   */
  public enum GameType {
    BASIC, RELAXED, TRIPEAKS
  }

  /**
   * Creates an instance of the desired pyramid solitaire GameType.
   *
   * @param type the type of pyramid solitaire game to be created.
   * @return an instanceof the GameType given.
   * @throws IllegalArgumentException if an invalid GameType is given.
   */
  public static PyramidSolitaireModel create(GameType type) {
    switch (type) {
      case BASIC:
        return new BasicPyramidSolitaire(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            gameState.NotPlaying);
      case RELAXED:
        return new RelaxedPyramidSolitaire(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            gameState.NotPlaying);
      case TRIPEAKS:
        return new TriPeaksPyramidSolitaire(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            gameState.NotPlaying);
      default:
        throw new IllegalArgumentException("Invalid input");
    }
  }
}
