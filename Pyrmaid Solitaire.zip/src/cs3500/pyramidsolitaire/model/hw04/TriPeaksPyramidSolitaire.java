package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.Card.Suits;
import cs3500.pyramidsolitaire.model.hw02.Card.Values;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Represents a game of TriPeaks Pyramid Solitaire. Pyramid is the current game of cards. Stock is
 * the deck of cards that can be drawn from. Status is the current state of the game: either Playing
 * or NotPlaying.
 */
public class TriPeaksPyramidSolitaire extends BasicPyramidSolitaire {

  /**
   * Constructs a TriPeaksPyramidSolitaire.
   *
   * @param pyramid the solitaire pyramid.
   * @param stock   the cards in the stock pile.
   * @param draw    the cards in the draw pile.
   * @param status  the state of the game.
   */
  public TriPeaksPyramidSolitaire(List<ArrayList<Card>> pyramid, List<Card> stock,
      List<Card> draw, gameState status) {
    this.pyramid = pyramid;
    this.stock = stock;
    this.draw = draw;
    this.status = status;
  }

  /**
   * Initializes a game of pyramid solitaire.
   */
  public TriPeaksPyramidSolitaire() {
    status = gameState.NotPlaying;
    pyramid = new ArrayList<ArrayList<Card>>();

  }

  @Override
  public List<Card> getDeck() {
    List<Card> result = new ArrayList<Card>();
    while (result.size() < 104) {
      for (Values v : Values.values()) {
        for (Suits s : Suits.values()) {
          result.add(new Card(v, s));
        }
      }
    }
    return result;
  }


  @Override
  public void startGame(List<Card> deck, boolean shouldShuffle, int numRows, int numDraw) {
    List<ArrayList<Card>> game = new ArrayList<ArrayList<Card>>();
    if (deck == null) {
      throw new IllegalArgumentException("Invalid input");
    }
    if (deck.size() != 104) {
      throw new IllegalArgumentException("Invalid input");
    }
    if (anyDups(deck)) {
      throw new IllegalArgumentException("Invalid input");
    }
    if ((numRows < 1) || (numRows > 10)) {
      throw new IllegalArgumentException("Invalid input");
    }
    if (numDraw < 0 || (numDraw > maxDraw(numRows))) {
      throw new IllegalArgumentException("Invalid input");
    } else {
      status = gameState.Playing;
      draw = new ArrayList<>();
      pyramid = new ArrayList<ArrayList<Card>>();
      stock = new ArrayList<>();
      stock.addAll(deck);

      if (!(shouldShuffle)) {
        this.pyramid = (createPyramid(stock, numRows, game));
        this.draw = getDraw(numDraw);
      } else {
        Collections.shuffle(stock);
        this.pyramid = (createPyramid(stock, numRows, game));
        this.draw = getDraw(numDraw);
      }
    }
  }

  private Integer maxDraw(int draw) {
    switch (draw) {
      case 1:
        return 101;
      case 2:
        return 95;
      case 3:
        return 86;
      case 4:
        return 76;
      case 5:
        return 65;
      case 6:
        return 53;
      case 7:
        return 40;
      case 8:
        return 26;
      case 9:
        return 11;
      default:
        throw new IllegalArgumentException("Invalid input");
    }
  }


  private boolean anyDups(List<Card> deck) {
    ArrayList result = new ArrayList();
    for (int i = 0; i < deck.size(); i++) {
      for (int j = i + 1; j < deck.size(); j++) {
        if (deck.get(i).equals(deck.get(j))) {
          result.add(j);
        }
      }

    }
    return (result.size() != (deck.size() / 2));
  }

  /**
   * Creates a pyramid out of a deck of cards based on number of rows requested.
   */
  public List<ArrayList<Card>> createPyramid(List<Card> stock, int numRows,
      List<ArrayList<Card>> board) {
    double count = numRows - Math.ceil((double) numRows / 2);
    double nullCount = numRows - Math.ceil((double) numRows / 2);
    for (int i = 0; i < numRows; i++) {
      ArrayList<Card> newRow = new ArrayList<>();
      if (i < Math.ceil(numRows / 2)) {
        for (int j = 0; j < count; j++) {
          newRow.add(stock.get(j));
          if (nullCount == 1) {
            newRow.add(stock.get(j + 1));
          }
          for (int x = 0; x < (nullCount - 1); x++) {
            newRow.add(null);
          }
        }
        for (int k = 0; k < count; k++) {
          stock.remove(0);
        }
        count += numRows - Math.ceil((double) numRows / 2);
        nullCount -= 1;
      } else {
        for (int j = 0; j < count; j++) {
          newRow.add(stock.get(j));
        }
        for (int k = 0; k < count; k++) {
          stock.remove(0);
        }
        count += 1;
      }
      board.add(newRow);
    }
    return board;
  }

}
