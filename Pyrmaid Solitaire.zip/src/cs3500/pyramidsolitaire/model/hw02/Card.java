package cs3500.pyramidsolitaire.model.hw02;

/**
 * Cards represent a card in a deck of cards.
 */
public class Card {

  /**
   * Suits represents the four possible suits of a card.
   */
  public enum Suits {
    Hearts, Diamonds, Clubs, Spades
  }

  /**
   * Values represents all the possible values a card can have.
   */
  public enum Values {
    A(1), Two(2), Three(3), Four(4), Five(5), Six(6), Seven(7), Eight(8), Nine(9), Ten(10),
    Jack(11), Queen(12), King(13);

    private int val;

    Values(int val) {
      this.val = val;
    }

    public int getNumVal() {
      return this.val;
    }

  }

  private final Values val;
  private final Suits suit;

  /**
   * Constructs a Card.
   *
   * @param val  the value of the card.
   * @param suit the suit of the card.
   */
  public Card(Values val, Suits suit) {
    if (!(suit instanceof Suits)) {
      throw new IllegalArgumentException("Not a valid suit");
    }
    if (!(val instanceof Values)) {
      throw new IllegalArgumentException("Not a valid value");
    }

    this.val = val;
    this.suit = suit;

  }


  /**
   * Sums the values of two cards.
   *
   * @param c the card to be summed with this card.
   * @return the sume of two cards as an integer.
   */
  public int sumTwoCards(Card c) {
    if (c == null) {
      return this.val.getNumVal();
    } else {
      return this.val.getNumVal() + c.findSum();
    }
  }


  /**
   * finds the sum of this card.
   *
   * @return the sum as an integer.
   */
  public int findSum() {
    return this.val.getNumVal();
  }


  @Override
  public String toString() {
    if (1 < val.getNumVal() && val.getNumVal() <= 10) {
      return Integer.toString(val.getNumVal()) + suitChar(suit);
    } else {
      return specialCard(this) + suitChar(suit);
    }

  }

  /**
   * Draws one of the special cards(Ace, King, Queen, Jack).
   *
   * @return the symbol for the card as a string.
   */
  private String specialCard(Card c) {
    if (c.findSum() == 1) {
      return "A";
    }
    if (c.findSum() == 11) {
      return "J";
    }
    if (c.findSum() == 12) {
      return "Q";
    } else {
      return "K";
    }
  }

  Character suitChar(Suits s) {
    switch (s) {
      case Hearts:
        return '♥';
      case Diamonds:
        return '♦';
      case Spades:
        return '♠';
      case Clubs:
        return '♣';
      default:
        throw new IllegalArgumentException("Invalid card given");
    }
  }


  @Override
  public boolean equals(Object that) {
    if (!(that instanceof Card)) {
      return false;
    } else {
      Card c = (Card) that;
      return ((this.val == c.val) && (this.suit == c.suit));
    }
  }

  @Override
  public int hashCode() {
    return this.val.getNumVal() + (this.suit.name()).length();
  }

  /**
   * creates a copy of this card.
   *
   * @return the copy of the card.
   */
  public Card copyCard() {
    Values x = null;
    Suits y = null;
    for (Values v : Values.values()) {
      if (v.equals(this.val)) {
        x = v;
      }
    }
    for (Suits s : Suits.values()) {
      if (s.equals(this.suit)) {
        y = s;
      }
    }
    return new Card(x, y);
  }


}
