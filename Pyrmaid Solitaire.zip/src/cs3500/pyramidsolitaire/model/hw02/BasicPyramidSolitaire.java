package cs3500.pyramidsolitaire.model.hw02;

import cs3500.pyramidsolitaire.model.hw02.Card.Suits;

import cs3500.pyramidsolitaire.model.hw02.Card.Values;

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

/**
 * Represents a game of Pyramid Solitaire. Pyramid is the current game of cards. Stock is the deck
 * of cards that can be drawn from. Status is the current state of the game: either Playing or
 * NotPlaying.
 */
public class BasicPyramidSolitaire implements PyramidSolitaireModel<Card> {

  /**
   * gameState represents the two states of a pyramid solitaire game:Playing and NotPlaying.
   */
  public enum gameState {
    Playing, NotPlaying
  }

  protected List<ArrayList<Card>> pyramid;
  protected List<Card> stock;
  protected List<Card> draw;
  protected gameState status;

  /**
   * Constructs a BasicPyramidSolitaire.
   *
   * @param pyramid the solitaire pyramid.
   * @param stock   the cards in the stock pile.
   * @param draw    the cards in the draw pile.
   * @param status  the state of the game.
   */
  public BasicPyramidSolitaire(List<ArrayList<Card>> pyramid, List<Card> stock,
      List<Card> draw, gameState status) {
    this.pyramid = pyramid;
    this.stock = stock;
    this.draw = draw;
    this.status = status;

  }

  /**
   * Initializes a game of pyramid solitaire.
   */
  public BasicPyramidSolitaire() {
    status = gameState.NotPlaying;
    pyramid = new ArrayList<ArrayList<Card>>();

  }

  @Override
  public List<Card> getDeck() {
    List<Card> result = new ArrayList<Card>();
    for (Values v : Values.values()) {
      for (Suits s : Suits.values()) {
        result.add(new Card(v, s));
      }
    }
    return result;
  }

  @Override
  public void startGame(List<Card> deck, boolean shouldShuffle, int numRows, int numDraw) {
    List<ArrayList<Card>> game = new ArrayList<ArrayList<Card>>();
    if (deck == null) {
      throw new IllegalArgumentException("Invalid input");
    }
    if (deck.size() != 52) {
      throw new IllegalArgumentException("Invalid input");
    }
    for (int i = 0; i < deck.size(); i++) {
      for (int j = i + 1; j < deck.size(); j++) {
        if (deck.get(i).equals(deck.get(j))) {
          throw new IllegalArgumentException("Invalid input");
        }
      }
    }
    if ((numRows < 1) || (numRows > 9)) {
      throw new IllegalArgumentException("Invalid input");
    }
    if (numDraw < 0 || (numDraw > maxDrawCards(numRows))) {
      throw new IllegalArgumentException("Invalid input");
    } else {
      status = gameState.Playing;
      draw = new ArrayList<>();
      pyramid = new ArrayList<ArrayList<Card>>();
      stock = new ArrayList<>();
      for (Card c : deck) {
        stock.add(c.copyCard());
      }

      if (!(shouldShuffle)) {
        this.pyramid = (createPyramid(stock, numRows, game));
        this.draw = getDraw(numDraw);
      } else {
        Collections.shuffle(stock);
        this.pyramid = (createPyramid(stock, numRows, game));
        this.draw = getDraw(numDraw);
      }
    }
  }

  /**
   * creates the draw pile for the game.
   */
  public ArrayList<Card> getDraw(int count) {
    ArrayList<Card> result = new ArrayList<>();
    for (int i = 0; i < count; i++) {
      result.add(stock.get(i).copyCard());
    }
    return result;
  }


  /**
   * determines the max number of draw cards a pyramid solitaire game can have based on # of rows.
   */
  private int maxDrawCards(int numRows) {
    return 52 - (((numRows * numRows) + numRows) / 2);
  }


  /**
   * Creates a pyramid out of a deck of cards based on number of rows requested.
   */
  protected List<ArrayList<Card>> createPyramid(List<Card> stock, int numRows,
      List<ArrayList<Card>> board) {
    for (int i = 0; i < numRows; i++) {
      ArrayList<Card> newRow = new ArrayList<>();
      for (int j = 0; j <= i; j++) {
        newRow.add(stock.get(j));
      }
      for (int k = 0; k <= i; k++) {
        stock.remove(0);
      }
      board.add(newRow);
    }
    return board;
  }


  @Override
  public void remove(int row1, int card1, int row2, int card2) throws IllegalStateException {
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    }
    if ((!(isExposed(row1, card1))) || (!(isExposed(row2, card2)))) {
      throw new IllegalArgumentException("The game has not started");
    }
    if ((this.getCardAt(row1, card1).sumTwoCards(this.getCardAt(row2, card2)) == 13)) {
      this.pyramid.get(row1).remove(card1);
      replaceCard(row1, card1);
      this.pyramid.get(row2).remove(card2);
      replaceCard(row2, card2);
    } else {
      throw new IllegalArgumentException("You can't make that move");
    }
  }

  @Override
  public void remove(int row, int card) throws IllegalStateException {
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    }
    if (!(isExposed(row, card))) {
      throw new IllegalArgumentException("The card is not exposed.");
    }
    if (getCardAt(row, card) == null) {
      throw new IllegalArgumentException("There is no card there.");
    }
    if ((this.getCardAt(row, card).findSum() == 13)) {
      this.pyramid.get(row).remove(card);
      this.replaceCard(row, card);
    } else {
      throw new IllegalArgumentException("You can't make that move");
    }
  }

  @Override
  public void removeUsingDraw(int drawIndex, int row, int card) throws IllegalStateException {
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    }
    if (drawIndex > draw.size()) {
      throw new IllegalArgumentException("Draw index is invalid");
    }
    if (draw.get(drawIndex) == null) {
      throw new IllegalArgumentException("There is no draw card there.");
    }
    if (getCardAt(row, card) == null) {
      throw new IllegalArgumentException("There is no card there.");
    }
    if ((draw.get(drawIndex).sumTwoCards(this.getCardAt(row, card)) == 13)
        && isExposed(row, card)) {
      this.pyramid.get(row).remove(card);
      replaceCard(row, card);
      discardDraw(drawIndex);

    } else {
      throw new IllegalArgumentException("You can't make that move");
    }
  }

  //replaces the removed card with null value.
  private void replaceCard(int row, int card) {
    if (card == pyramid.get(row).size()) {
      this.pyramid.get(row).add(null);
    } else {
      this.pyramid.get(row).add(card, null);
    }
  }


  @Override
  public void discardDraw(int drawIndex) throws IllegalStateException {
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    }
    if (draw.get(drawIndex) == null) {
      throw new IllegalArgumentException("There is no card there.");
    }
    if (drawIndex >= draw.size()) {
      throw new IllegalArgumentException("Invalid index given.");
    }
    if (!(this.stock.isEmpty())) {
      draw.remove(drawIndex);
      draw.add(drawIndex, stock.get(0));
    } else {
      draw.remove(drawIndex);
    }
  }

  @Override
  public int getNumRows() {
    if (status == gameState.NotPlaying) {
      return -1;
    } else {
      return this.pyramid.size();
    }
  }

  @Override
  public int getNumDraw() {
    int count = 0;
    if (status == gameState.NotPlaying) {
      return -1;
    } else {
      return draw.size();
    }
  }

  @Override
  public int getRowWidth(int row) {
    if (this.status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started yet.");
    }
    if (row > pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid input.");
    } else {
      return pyramid.get(row).size();
    }
  }

  @Override
  public boolean isGameOver() throws IllegalStateException {
    ArrayList<Boolean> result = new ArrayList<>();
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    }
    if (this.getScore() == 0) {
      return true;
    }
    if (!(stock.isEmpty())) {
      return false;
    }
    if (this.anyDraws()) {
      return false;
    } else {
      return (!((this.anySingleMoves(getAllExposed())) || (this.anyOtherMoves(getAllExposed())
          && (stock.isEmpty()))));
    }
  }


  /**
   * checks if any cards can be removed using a draw card.
   */
  private boolean anyDraws() {
    ArrayList<Boolean> result = new ArrayList<>();
    for (Card c : draw) {
      if (c != null) {
        result.add(true);
      } else {
        result.add(false);
      }
    }
    return result.contains(true);
  }

  /**
   * checks if any cards in the list can be removed in a two card move.
   */
  private boolean anyOtherMoves(ArrayList<Card> check) {
    ArrayList<Card> cards = this.getAllExposed();
    cards.addAll(draw);
    ArrayList<Boolean> result = new ArrayList<>();
    for (int i = 0; i < check.size(); i++) {
      for (int j = i + 1; j < check.size(); j++) {
        if (cards.get(i) != null) {
          result.add((cards.get(i).sumTwoCards(cards.get(j))) == 13);
        }
      }
    }
    return result.contains(true);
  }

  /**
   * checks if any cards in the list can be removed in a single card move.
   */
  public boolean anySingleMoves(ArrayList<Card> check) {
    ArrayList<Boolean> result = new ArrayList<>();
    for (Card c : check) {
      result.add(c.findSum() == 13);
    }
    return result.contains(true);
  }

  /**
   * returns an array list of all the exposed cards in the pyramid.
   */
  private ArrayList<Card> getAllExposed() {
    ArrayList<Card> result = new ArrayList<>();
    for (int i = 0; i < pyramid.size(); i++) {
      for (int j = 0; j < pyramid.get(i).size(); j++) {
        if (isExposed(i, j)) {
          result.add(getCardAt(i, j));
        }
      }
    }
    return result;
  }


  @Override
  public int getScore() throws IllegalStateException {
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    } else {
      int score = 0;
      for (ArrayList<Card> cards : this.pyramid) {
        score += sumOneRow(cards);
      }
      return score;
    }
  }


  /**
   * returns a sum of the cards in a single row.
   */
  private int sumOneRow(ArrayList<Card> row) {
    int result = 0;
    for (Card c : row) {
      if (c == null) {
        result += 0;
      } else {
        result += c.findSum();
      }
    }
    return result;
  }

  @Override
  public Card getCardAt(int row, int card) throws IllegalStateException {
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    }
    if (row > this.pyramid.size() - 1) {
      throw new IllegalArgumentException("Invalid input.");
    }
    if (card > this.pyramid.get(row).size() - 1) {
      throw new IllegalArgumentException("Invalid input.");
    } else {
      return this.pyramid.get(row).get(card);
    }
  }

  @Override
  public List<Card> getDrawCards() throws IllegalStateException {
    List<Card> result = new ArrayList<>();
    if (status == gameState.NotPlaying) {
      throw new IllegalStateException("The game has not started");
    } else {
      for (int i = 0; i < draw.size(); i++) {
        if (draw.get(i) != null) {
          result.add(i, draw.get(i).copyCard());
        }
      }
    }
    return result;
  }

  //checks if the card at the given indices is exposed.
  protected boolean isExposed(int row, int card) {
    if (row == getNumRows() - 1) {
      return true;
    } else {
      return (this.getCardAt(row + 1, card) == null
          && this.getCardAt(row + 1, card + 1) == null);
    }
  }
}
