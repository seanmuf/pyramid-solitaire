package cs3500.pyramidsolitaire.controller;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

/**
 * The controller for a game of Pyramid Solitaire. It reads user inputs and enacts the corresponding
 * move indicated on the game.
 */
public class PyramidSolitaireTextualController implements PyramidSolitaireController {

  private Readable rd;
  private Appendable ap;

  /**
   * Constructs a PyramidSolitaireTextualController.
   *
   * @param rd the readable representing user input.
   * @param ap the appendable representing the controller's input.
   * @throws IllegalArgumentException if the readable or appendable is null.
   */
  public PyramidSolitaireTextualController(Readable rd, Appendable ap)
      throws IllegalArgumentException {

    if ((rd == null) || (ap == null)) {
      throw new IllegalArgumentException("Invalid Argument");
    }

    this.rd = rd;
    this.ap = ap;

  }

  @Override
  public <K> void playGame(PyramidSolitaireModel<K> model, List<K> deck, boolean shuffle,
      int numRows, int numDraw) {
    if (model == null) {
      throw new IllegalArgumentException("Model can't be null.");
    }
    try {
      model.startGame(deck, shuffle, numRows, numDraw);
    } catch (Exception e) {
      throw new IllegalStateException(e.getMessage());
    }

    int card1;
    int card2;
    int row1;
    int row2;
    int draw;
    String mov = "";

    Scanner sc = new Scanner(rd);
    while (sc.hasNext()) {
      try {
        mov = getMove(sc.next(), sc);
      } catch (Exception e) {
        try {
          if (e.getMessage().equals("Game Quit!")) {
            ap.append("Game quit!" + "\n");
            ap.append("State of game when quit:" + "\n");
            new PyramidSolitaireTextualView(model, ap).render() ;
            ap.append("\n" + "Score: " + model.getScore());
            break;
          }
        } catch (IOException x) {
          throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
        }
      }

      if (mov.equals("rm1")) {
        try {
          row1 = moveInput(sc.next(), sc);
          card1 = moveInput(sc.next(), sc);
          model.remove(row1 - 1, card1 - 1);
          ap.append(model.toString() + "\n");
          ap.append("Score: " + model.getScore() + "\n");
          new PyramidSolitaireTextualView(model, ap).render();
          if (model.isGameOver()) {
            try {
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append( "\n" + "Game Over. Score: " + model.getScore());
              break;
            } catch (Exception x) {
              throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
            }
          }
        } catch (Exception e) {
          try {
            if (e.getMessage().equals("Game Quit!")) {
              ap.append("Game quit!" + "\n");
              ap.append("State of game when quit:" + "\n");
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append("\n" + "Score: " + model.getScore());
              break;
            }
            if (e.getMessage().equals("You can't make that move")) {
              ap.append("Invalid move. Play again. " + e.getMessage() + "\n");
            }
          } catch (IOException x) {
            throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
          }
        }
      }

      if (mov.equals("rm2")) {
        try {
          row1 = moveInput(sc.next(), sc);
          card1 = moveInput(sc.next(), sc);
          row2 = moveInput(sc.next(), sc);
          card2 = moveInput(sc.next(), sc);
          model.remove(row1 - 1, card1 - 1, row2 - 1, card2 - 1);
          ap.append(model.toString() + "\n");
          ap.append("Score: " + model.getScore() + "\n");
          new PyramidSolitaireTextualView(model, ap).render();
          if (model.isGameOver()) {
            try {
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append( "\n" + "Game Over. Score: " + model.getScore());
              break;
            } catch (Exception x) {
              throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
            }
          }
        } catch (Exception e) {
          try {
            if (e.getMessage().equals("Game Quit!")) {
              ap.append("Game quit!" + "\n");
              ap.append("State of game when quit:" + "\n");
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append("\n" + "Score: " + model.getScore());
              break;
            }
            if (e.getMessage().equals("You can't make that move")) {
              ap.append("Invalid move. Play again. " + e.getMessage() + "\n");
            }
          } catch (IOException x) {
            throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
          }
        }
      }

      if (mov.equals("rmwd")) {
        try {
          draw = moveInput(sc.next(), sc);
          row1 = moveInput(sc.next(), sc);
          card1 = moveInput(sc.next(), sc);
          model.removeUsingDraw(draw, row1 - 1, card1 - 1);
          ap.append(model.toString() + '\n');
          ap.append("Score: " + model.getScore() + "\n");
          new PyramidSolitaireTextualView(model, ap).render();
          if (model.isGameOver()) {
            try {
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append( "\n" + "Game Over. Score: " + model.getScore());
              break;
            } catch (Exception x) {
              throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
            }
          }
        } catch (Exception e) {
          try {
            if (e.getMessage().equals("Game Quit!")) {
              ap.append("Game quit!" + "\n");
              ap.append("State of game when quit:" + "\n");
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append("\n" + "Score: " + model.getScore());
              break;
            }
            if (e.getMessage().equals("You can't make that move")) {
              ap.append("Invalid move. Play again. " + e.getMessage() + "\n");
            }
          } catch (IOException x) {
            throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
          }
        }
      }

      if (mov.equals("dd")) {
        try {
          draw = moveInput(sc.next(), sc);
          model.discardDraw(draw);
          ap.append(model.toString() + "\n");
          ap.append("Score: " + model.getScore() + "\n");
          new PyramidSolitaireTextualView(model, ap).render();
          if (model.isGameOver()) {
            try {
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append( "\n" + "Game Over. Score: " + model.getScore());
              break;
            } catch (Exception x) {
              throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
            }
          }
        } catch (Exception e) {
          try {
            if (e.getMessage().equals("Game Quit!")) {
              ap.append("Game quit!" + "\n");
              ap.append("State of game when quit:" + "\n");
              new PyramidSolitaireTextualView(model, ap).render();
              ap.append("\n" + "Score: " + model.getScore());
              break;
            }
          } catch (IOException x) {
            throw new IllegalStateException("IO exception " + x.getMessage() + "\n");
          }
        }
      }

    }
    if (model.getScore() == 0) {
      try {
        ap.append("You win!" + "\n");
        new PyramidSolitaireTextualView(model, ap).render();
      } catch (Exception e) {
        throw new IllegalStateException("IO exception " + e.getMessage() + "\n");
      }
    }


  }

  //Returns the given input as an integer. If it's not, goes through scanner until integer is found.
  private int moveInput(String input, Scanner sc) {
    int num = 0;
    if ((input.equals("q")) || (input.equals("Q"))) {
      throw new IllegalArgumentException("Game Quit!");
    }
    try {
      Integer.parseInt(input);
      num = Integer.parseInt(input);
    } catch (Exception e) {
      if (sc.hasNext()) {
        moveInput(sc.next(), sc);
      }
    }
    return num;
  }

  // Returns the given move as a String. If it's not a valid move, goes through scanner until one
  // is found.
  private String getMove(String move, Scanner sc) {
    switch (move) {
      case "rm1":
        return "rm1";
      case "rm2":
        return "rm2";
      case "rmwd":
        return "rmwd";
      case "dd":
        return "dd";
      case "q":
      case "Q":
        throw new IllegalArgumentException("Game Quit!");
      default:
        if (sc.hasNext()) {
          getMove(sc.next(), sc);
        }
    }
    return move;
  }

}
